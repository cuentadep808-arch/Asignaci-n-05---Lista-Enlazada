
package linkedlist;

public class LinkedList {

    public static void main(String[] args) {

        ListaEnlazada<String> lista = new ListaEnlazada<>();

        lista.append("A");
        lista.append("B");
        lista.append("C");

        System.out.println("Lista inicial:");

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        lista.insert("X", 1);

        System.out.println("\nDespues de insertar X:");

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        System.out.println("\nElemento en indice 2: " + lista.get(2));

        String eliminado = lista.remove(1);

        System.out.println("\nElemento eliminado: " + eliminado);

        System.out.println("\nLista despues de eliminar:");

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        System.out.println("\nCantidad de elementos: " + lista.size());

        System.out.println("Indice de C: " + lista.indexOf("C"));

        lista.set("Z", 0);

        System.out.println("\nDespues de cambiar el primer elemento:");

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        lista.removeObj("C");

        System.out.println("\nDespues de eliminar C:");

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        lista.clear();

        System.out.println("\nDespues de clear:");
        System.out.println("Tamano: " + lista.size());
        System.out.println("Esta vacia: " + lista.empty());
    }
}
