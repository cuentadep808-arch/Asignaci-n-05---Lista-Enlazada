
package linkedlist;

import java.util.Iterator;
import java.util.Spliterator;
import java.util.function.Consumer;

public class ListaEnlazada<T> implements IList<T>, Iterable<T> {

    protected NodoSimple<T> inicio;
    protected int nElementos;

    private class NodoSimple<T> {

        private T dato;
        private NodoSimple<T> sig;

        public NodoSimple(T dato) {
            this.dato = dato;
            this.sig = null;
        }
    }

    public ListaEnlazada() {
        inicio = null;
        nElementos = 0;
    }

    @Override
    public void append(T elemento) throws ListException {
        NodoSimple<T> nodoNuevo = new NodoSimple<>(elemento);
        NodoSimple<T> nodo = inicio;

        if (nodo == null) {
            inicio = nodoNuevo;
        } else {
            while (nodo.sig != null) {
                nodo = nodo.sig;
            }
            nodo.sig = nodoNuevo;
        }

        nElementos++;
    }

    @Override
    public void insert(T elemento, int index) throws ListException {

        if (index < 0 || index > nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoSimple<T> nodoNuevo = new NodoSimple<>(elemento);

        if (index == 0) {
            nodoNuevo.sig = inicio;
            inicio = nodoNuevo;
        } else {
            NodoSimple<T> nodo = inicio;

            for (int i = 0; i < index - 1; i++) {
                nodo = nodo.sig;
            }

            nodoNuevo.sig = nodo.sig;
            nodo.sig = nodoNuevo;
        }

        nElementos++;
    }

    @Override
    public T remove(int index) throws ListException {

        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoSimple<T> eliminado;

        if (index == 0) {
            eliminado = inicio;
            inicio = inicio.sig;
        } else {
            NodoSimple<T> nodo = inicio;

            for (int i = 0; i < index - 1; i++) {
                nodo = nodo.sig;
            }

            eliminado = nodo.sig;
            nodo.sig = eliminado.sig;
        }

        nElementos--;

        return eliminado.dato;
    }

    @Override
    public boolean removeObj(T elemento) throws ListException {

        int indice = indexOf(elemento);

        if (indice == -1) {
            return false;
        }

        remove(indice);
        return true;
    }

    @Override
    public int indexOf(T elemento) {

        NodoSimple<T> nodo = inicio;
        int indice = 0;

        while (nodo != null) {

            if (elemento == null) {
                if (nodo.dato == null) {
                    return indice;
                }
            } else if (elemento.equals(nodo.dato)) {
                return indice;
            }

            nodo = nodo.sig;
            indice++;
        }

        return -1;
    }

    @Override
    public T get(int index) throws ListException {

        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoSimple<T> nodo = inicio;

        for (int i = 0; i < index; i++) {
            nodo = nodo.sig;
        }

        return nodo.dato;
    }

    @Override
    public void set(T elemento, int index) throws ListException {

        if (index < 0 || index >= nElementos) {
            throw new ListException("Indice fuera de rango");
        }

        NodoSimple<T> nodo = inicio;

        for (int i = 0; i < index; i++) {
            nodo = nodo.sig;
        }

        nodo.dato = elemento;
    }

    @Override
    public void clear() {
        inicio = null;
        nElementos = 0;
    }

    @Override
    public boolean empty() {
        return nElementos == 0;
    }

    @Override
    public int size() {
        return nElementos;
    }

    @Override
    public Iterator<T> Iterator() {
        return iterator();
    }

    @Override
    public Iterator<T> iterator() {

        return new Iterator<T>() {

            private NodoSimple<T> actual = inicio;

            @Override
            public boolean hasNext() {
                return actual != null;
            }

            @Override
            public T next() {
                T dato = actual.dato;
                actual = actual.sig;
                return dato;
            }
        };
    }

    @Override
    public void forEach(Consumer<? super T> action) {
        Iterable.super.forEach(action);
    }

    @Override
    public Spliterator<T> spliterator() {
        return Iterable.super.spliterator();
    }
}